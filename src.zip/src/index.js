import react from 'react';
import  ReactDOM  from 'react-dom';
import App from './App'
import Loginform from './loginform'
import createacc from './createacc'
import {BrowserRouter,Routes,Route} from "react-router-dom";

ReactDOM.render(<App />,document.getElementById('root'))